package support;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author         :VNatarajan
 * @since          :Sep 25, 2017
 * @filename       :DataReader.java
 * @version		   :
 * @description    :
 */
public abstract class DataReader {
	
		
	public String get(String string) {
		return string;
		
	}

	public String getTestId() {
		return null;
	}
	
	

	public List<Map<String, String>> getList(String columnNames) {
		return null;
	}

}
