package support;

public enum BrowserName {
	Firefox ,

	Chrome,
	
	InternetExplorer,
	
	Edge,
	
	Safari,
	
	HtmlUnitDriver
}
