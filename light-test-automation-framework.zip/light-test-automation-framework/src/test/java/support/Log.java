package support;

import com.aventstack.extentreports.Status;

public class Log {
	
	public Status status = Status.INFO;
	public String message = "";
	
}
