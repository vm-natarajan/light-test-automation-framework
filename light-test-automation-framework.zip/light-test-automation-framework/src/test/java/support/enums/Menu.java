package support.enums;

public enum Menu {
	CONTACT_US {
		public String toString() {
			return "Contact us";
		}
	},
	
	SIGN_IN{
		public String toString() {
			return "Sign in";
		}
	},
	 
	 WOMEN{
		public String toString() {
			return "Women";
		}
	},
	
	DRESSES{
		public String toString() {
			return "Dresses";
		}
	},
	
	TSHIRTS{
		public String toString() {
			return "T-shirts";
		}
	},
}




