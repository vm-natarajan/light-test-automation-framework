package support.enums;

public enum Commodity {
	 ELECTRICITY {
	      public String toString() {
	          return "Electric";
	      }
	  },

	  Gas {
	      public String toString() {
	          return "Gas";
	      }
	  }
	}

